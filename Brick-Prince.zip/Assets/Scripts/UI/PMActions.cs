using UnityEngine;
using Platformer.UI;
using UnityEngine.SceneManagement;

public class PMActions : MonoBehaviour
{

    public void ShowDefeatScreen()
    {
        if (GameResultUI.Instance != null)
            GameResultUI.Instance.ShowDefeat();
        else
            GoToMainMenu();
    }

    public void GoToMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

}
